import React from 'react';
import { motion } from 'motion/react';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

export function HowItWorks() {
  return (
    <section className="lg:col-span-4 bg-blue-900 rounded-3xl p-8 text-white flex flex-col justify-between shadow-lg">
      <div className="w-full">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-4">
            The Truth About Your Oral Health
          </h2>
          <p className="text-blue-100">
            Recent studies have revealed a shocking truth: common dental products like toxic toothpaste and mouthwash may actually be destroying the good bacteria in your mouth.
          </p>
        </div>

        <div className="flex flex-col gap-6">
          <motion.div 
            className="bg-white/10 p-6 rounded-2xl border border-white/20"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center shrink-0">
                <AlertCircle className="w-5 h-5 text-red-400" />
              </div>
              <h3 className="text-xl font-bold">The Problem</h3>
            </div>
            <p className="text-blue-50 text-sm leading-relaxed">
              Everyday dental products contain harsh chemicals that destroy beneficial microbes, leaving your teeth defenseless against decay and gums vulnerable.
            </p>
          </motion.div>

          <motion.div 
            className="bg-white/10 p-6 rounded-2xl border border-white/20"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-5 h-5 text-green-400" />
              </div>
              <h3 className="text-xl font-bold">The Solution</h3>
            </div>
            <p className="text-blue-50 text-sm leading-relaxed">
              <strong>ProDentim</strong> repopulates your mouth with 3.5 billion beneficial bacteria. Melt one probiotic candy daily to support a healthy mouth environment.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
