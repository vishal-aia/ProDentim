export const AFFILIATE_LINK = "https://e38bdgnnykj0l4fjyit20osj3r.hop.clickbank.net";
